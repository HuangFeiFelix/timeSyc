/*
 * smsc9303.h - routines to initialize SMSC 9303 switch
 *
 * Copyright (c) 2010 BCT Electronic GmbH
 *
 * Licensed under the GPL-2 or later.
 */

int init_smsc9303i_mii(void);
