#define GPIO_PIN_1 GPIO_PH0
#include "../cm-bf537e/gpio_cfi_flash.c"
